import { useRef, useState, type ReactNode } from 'react';
import { Trash2, Upload } from 'lucide-react';
import { fileToDataUrl, imageToDataUrl } from '../lib/image';

export function Card({ title, children, hint }: { title: string; children: ReactNode; hint?: string }) {
  return (
    <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <h3 className="font-display text-xl uppercase tracking-wide text-white">{title}</h3>
      {hint && <p className="mt-1 text-xs text-white/50">{hint}</p>}
      <div className="mt-4 space-y-4">{children}</div>
    </section>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-bold uppercase tracking-widest text-white/60">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-white/40">{hint}</span>}
    </label>
  );
}

const input = 'w-full rounded-lg border border-white/15 bg-black px-3 py-2 text-sm text-white outline-none focus:border-brisa';

export function Text({ value, onChange, placeholder, type = 'text' }: { value: string | number; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return <input type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className={input} />;
}
export function Area({ value, onChange, rows = 3 }: { value: string; onChange: (v: string) => void; rows?: number }) {
  return <textarea rows={rows} value={value} onChange={(e) => onChange(e.target.value)} className={input} />;
}
export function NumberInput({ value, onChange, min = 0, step = 1 }: { value: number; onChange: (v: number) => void; min?: number; step?: number }) {
  return <input type="number" min={min} step={step} value={Number.isFinite(value) ? value : 0} onChange={(e) => onChange(Number(e.target.value))} className={input} />;
}

export function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-white/10 bg-black/40 px-3 py-2">
      <span className="text-sm text-white/90">{label}</span>
      <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? 'bg-brisa' : 'bg-white/20'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </label>
  );
}

export function Range({ label, value, onChange, min, max, step = 1, unit = '' }: { label: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number; unit?: string }) {
  return (
    <label className="block rounded-lg border border-white/10 bg-black/40 px-3 py-2">
      <span className="flex justify-between text-sm text-white/90"><span>{label}</span><b className="text-brisa">{value}{unit}</b></span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="mt-2 w-full accent-[#e10b24]" />
    </label>
  );
}

export function ColorInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center gap-2">
      <input type="color" value={/^#[0-9a-f]{6}$/i.test(value) ? value : '#000000'} onChange={(e) => onChange(e.target.value)} className="h-10 w-12 cursor-pointer rounded border border-white/15 bg-black p-0.5" />
      <input value={value} onChange={(e) => onChange(e.target.value)} className={input} />
    </div>
  );
}

/** Upload de imagem com pré-visualização, remoção e URL manual. */
export function ImageUpload({ value, onChange, maxSide = 1100, checker = false }: { value: string; onChange: (v: string) => void; maxSide?: number; checker?: boolean }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const pick = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try { onChange(await imageToDataUrl(f, maxSide)); } catch { alert('Não foi possível ler essa imagem.'); }
    setBusy(false);
  };
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-lg border border-white/15" style={{ background: checker ? 'repeating-conic-gradient(#222 0% 25%, #333 0% 50%) 50%/16px 16px' : '#000' }}>
        {value ? <img src={value} alt="" className="max-h-full max-w-full object-contain" /> : <span className="text-[10px] text-white/40">sem imagem</span>}
      </div>
      <div className="flex flex-1 flex-col gap-2">
        <div className="flex gap-2">
          <button type="button" onClick={() => ref.current?.click()} className="flex items-center gap-2 rounded-lg bg-brisa px-3 py-2 text-xs font-bold uppercase tracking-widest text-white hover:brightness-110">
            <Upload size={14} /> {busy ? 'Enviando…' : 'Enviar'}
          </button>
          {value && <button type="button" onClick={() => onChange('')} className="rounded-lg border border-white/20 px-3 py-2 text-white/70 hover:bg-white/10" aria-label="Remover"><Trash2 size={14} /></button>}
        </div>
        <input value={value.startsWith('data:') ? '' : value} placeholder={value.startsWith('data:') ? '(imagem enviada)' : 'ou cole uma URL'} onChange={(e) => onChange(e.target.value)} className={input} />
      </div>
      <input ref={ref} type="file" accept="image/*" hidden onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ''; }} />
    </div>
  );
}

/** Upload genérico (modelo 3D .glb, GIF…) guardado como data URL. */
export function FileUpload({ value, onChange, accept, label, maxMB = 25 }: { value: string; onChange: (v: string) => void; accept: string; label: string; maxMB?: number }) {
  const ref = useRef<HTMLInputElement>(null);
  const [name, setName] = useState('');
  const pick = async (f?: File) => {
    if (!f) return;
    if (f.size > maxMB * 1024 * 1024) { alert(`Arquivo maior que ${maxMB} MB.`); return; }
    onChange(await fileToDataUrl(f));
    setName(f.name);
  };
  return (
    <div className="flex items-center gap-3">
      <button type="button" onClick={() => ref.current?.click()} className="flex items-center gap-2 rounded-lg bg-brisa px-3 py-2 text-xs font-bold uppercase tracking-widest text-white hover:brightness-110">
        <Upload size={14} /> {label}
      </button>
      {value && <button type="button" onClick={() => { onChange(''); setName(''); }} className="rounded-lg border border-white/20 px-3 py-2 text-white/70 hover:bg-white/10" aria-label="Remover"><Trash2 size={14} /></button>}
      <span className="truncate text-xs text-white/60">{value ? name || 'arquivo enviado' : 'nenhum arquivo'}</span>
      <input ref={ref} type="file" accept={accept} hidden onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ''; }} />
    </div>
  );
}
