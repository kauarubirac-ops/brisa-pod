import { useRef, useState } from 'react';
import { useStore } from '../store';
import type { AnimSettings, Settings } from '../types';
import { DEFAULT_STATE } from '../defaults';
import { EASINGS, download } from '../lib/util';
import { Area, Card, ColorInput, Field, FileUpload, ImageUpload, Range, Text, Toggle } from './ui';

function useSettings() {
  const { state, update } = useStore();
  const set = (patch: Partial<Settings>) => update((s) => ({ ...s, settings: { ...s.settings, ...patch } }));
  const setAnim = (patch: Partial<AnimSettings>) => update((s) => ({ ...s, settings: { ...s.settings, anim: { ...s.settings.anim, ...patch } } }));
  return { s: state.settings, set, setAnim, state, update };
}

/* ---------- HERO ---------- */
export function HeroTab() {
  const { s, set, state, update } = useSettings();
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Textos do hero">
        <Field label="Texto gigante de fundo" hint="Aparece atrás dos produtos (ex.: BRISA)"><Text value={s.ghostText} onChange={(v) => set({ ghostText: v })} /></Field>
        <Field label="Título padrão (quando não há produto)"><Text value={s.heroLabel} onChange={(v) => set({ heroLabel: v })} /></Field>
        <Field label="Texto padrão"><Area value={s.heroText} onChange={(v) => set({ heroText: v })} /></Field>
        <Field label="Texto do botão “Ver catálogo”"><Text value={s.ctaLabel} onChange={(v) => set({ ctaLabel: v })} /></Field>
      </Card>

      <Card title="Modelo 3D do hero" hint="Envie seu .glb aqui para substituir o antigo. Quando ativado, o produto do centro do carrossel vira o modelo 3D girando.">
        <Field label="Modelo 3D padrão (.glb)">
          <FileUpload value={s.heroModel} onChange={(v) => set({ heroModel: v })} accept=".glb,.gltf,model/gltf-binary" label="Enviar modelo .glb" />
        </Field>
        <Toggle label="Usar 3D no centro do hero" checked={s.useModelInHero} onChange={(v) => set({ useModelInHero: v })} />
        <p className="text-[11px] text-white/40">Produtos com modelo próprio usam o deles; os demais usam este modelo padrão.</p>
      </Card>

      <Card title="Fumaça (GIF de fundo)" hint="GIF/imagem usado no fundo do site com mistura “screen”.">
        <Field label="Arquivo de fundo"><ImageUpload value={s.bgGif} onChange={(v) => set({ bgGif: v })} maxSide={1600} /></Field>
      </Card>

      <Card title="Quais produtos aparecem no carrossel">
        <div className="space-y-2">
          {state.products.map((p) => (
            <div key={p.id} className="flex items-center gap-3 rounded-lg border border-white/10 bg-black/40 p-2">
              <img src={p.image} alt="" className="h-12 w-9 object-contain" style={{ background: p.bg }} />
              <span className="flex-1 text-sm text-white">{p.name}</span>
              <input type="color" value={p.bg} onChange={(e) => update((st) => ({ ...st, products: st.products.map((x) => (x.id === p.id ? { ...x, bg: e.target.value } : x)) }))} className="h-8 w-10 cursor-pointer rounded border border-white/15 bg-black p-0.5" title="Cor de fundo" />
              <input type="checkbox" checked={p.featured} onChange={(e) => update((st) => ({ ...st, products: st.products.map((x) => (x.id === p.id ? { ...x, featured: e.target.checked } : x)) }))} className="h-5 w-5 accent-[#e10b24]" />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ---------- MARCA ---------- */
export function BrandTab() {
  const { s, set } = useSettings();
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Logo">
        <Field label="Logo do site (PNG transparente)"><ImageUpload value={s.logo} onChange={(v) => set({ logo: v })} maxSide={1000} checker /></Field>
        <Range label="Altura do logo no topo" value={s.logoHeight} min={24} max={120} unit="px" onChange={(v) => set({ logoHeight: v })} />
        <Field label="Nome da marca (título da aba)"><Text value={s.brandName} onChange={(v) => set({ brandName: v })} /></Field>
      </Card>

      <Card title="Cores" hint="Tema: vermelho, preto e branco.">
        <Field label="Vermelho principal"><ColorInput value={s.colors.red} onChange={(v) => set({ colors: { ...s.colors, red: v } })} /></Field>
        <Field label="Preto de fundo"><ColorInput value={s.colors.black} onChange={(v) => set({ colors: { ...s.colors, black: v } })} /></Field>
        <Field label="Cor do texto gigante (branco)"><ColorInput value={s.colors.ghost} onChange={(v) => set({ colors: { ...s.colors, ghost: v } })} /></Field>
        <button onClick={() => set({ colors: DEFAULT_STATE.settings.colors })} className="text-xs uppercase tracking-widest text-white/50 underline hover:text-white">Restaurar cores padrão</button>
      </Card>

      <Card title="Catálogo e sobre">
        <Field label="Título do catálogo"><Text value={s.catalogTitle} onChange={(v) => set({ catalogTitle: v })} /></Field>
        <Field label="Subtítulo"><Text value={s.catalogSubtitle} onChange={(v) => set({ catalogSubtitle: v })} /></Field>
        <Field label="Título da seção Marca"><Text value={s.aboutTitle} onChange={(v) => set({ aboutTitle: v })} /></Field>
        <Field label="Texto da seção Marca"><Area value={s.aboutText} onChange={(v) => set({ aboutText: v })} /></Field>
        <Field label="Frase do rodapé"><Text value={s.footerText} onChange={(v) => set({ footerText: v })} /></Field>
      </Card>

      <Card title="Vendas">
        <Field label="WhatsApp (com DDI e DDD)" hint="Ex.: 5553999999999. O botão “Pedir no WhatsApp” só aparece se preenchido."><Text value={s.whatsapp} onChange={(v) => set({ whatsapp: v })} placeholder="5553999999999" /></Field>
        <Field label="Mensagem do pedido" hint="Use {produto} para inserir o nome."><Text value={s.whatsappMessage} onChange={(v) => set({ whatsappMessage: v })} /></Field>
        <Field label="Moeda"><Text value={s.currency} onChange={(v) => set({ currency: v })} /></Field>
        <Toggle label="Mostrar quantidade em estoque no site" checked={s.showStock} onChange={(v) => set({ showStock: v })} />
        <Toggle label="Tela de confirmação +18 ao entrar" checked={s.ageGate} onChange={(v) => set({ ageGate: v })} />
      </Card>
    </div>
  );
}

/* ---------- ANIMAÇÕES ---------- */
export function AnimTab() {
  const { s, setAnim } = useSettings();
  const a = s.anim;
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Carrossel do hero">
        <Range label="Duração da transição" value={a.carouselMs} min={200} max={1800} step={50} unit="ms" onChange={(v) => setAnim({ carouselMs: v })} />
        <Field label="Curva de movimento">
          <select value={a.easing} onChange={(e) => setAnim({ easing: e.target.value })} className="w-full rounded-lg border border-white/15 bg-black px-3 py-2 text-sm text-white outline-none focus:border-brisa">
            {Object.keys(EASINGS).map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
        </Field>
        <Toggle label="Passar sozinho (autoplay)" checked={a.autoplay} onChange={(v) => setAnim({ autoplay: v })} />
        {a.autoplay && <Range label="Intervalo do autoplay" value={a.autoplayMs} min={2000} max={12000} step={500} unit="ms" onChange={(v) => setAnim({ autoplayMs: v })} />}
        <Toggle label="Produto central flutuando" checked={a.float} onChange={(v) => setAnim({ float: v })} />
        <Toggle label="Texto gigante com parallax do mouse" checked={a.ghostParallax} onChange={(v) => setAnim({ ghostParallax: v })} />
        <Toggle label="Botão elástico (mola)" checked={a.magnetic} onChange={(v) => setAnim({ magnetic: v })} />
      </Card>

      <Card title="Fumaça vermelha e fundo">
        <Toggle label="Fumaça em canvas (reage ao mouse)" checked={a.smokeCanvas} onChange={(v) => setAnim({ smokeCanvas: v })} />
        <Range label="Intensidade da fumaça" value={a.smokeIntensity} min={0} max={100} onChange={(v) => setAnim({ smokeIntensity: v })} />
        <Toggle label="Fumaça na frente do produto" checked={a.smokeFront} onChange={(v) => setAnim({ smokeFront: v })} />
        <Toggle label="GIF de fumaça no fundo" checked={a.gifBg} onChange={(v) => setAnim({ gifBg: v })} />
        <Range label="Opacidade do GIF" value={a.gifOpacity} min={0} max={100} unit="%" onChange={(v) => setAnim({ gifOpacity: v })} />
        <Toggle label="Granulado (grain)" checked={a.grain} onChange={(v) => setAnim({ grain: v })} />
        <Range label="Opacidade do granulado" value={a.grainOpacity} min={0} max={100} unit="%" onChange={(v) => setAnim({ grainOpacity: v })} />
      </Card>

      <Card title="Mouse e interação">
        <Toggle label="Cursor personalizado (ponto + anel)" checked={a.cursor} onChange={(v) => setAnim({ cursor: v })} />
        <Toggle label="Rastro vermelho do mouse" checked={a.trail} onChange={(v) => setAnim({ trail: v })} />
        <Toggle label="Luz vermelha nos cards (spotlight)" checked={a.spotlight} onChange={(v) => setAnim({ spotlight: v })} />
        <Toggle label="Cards inclinam com o mouse (tilt)" checked={a.tilt} onChange={(v) => setAnim({ tilt: v })} />
      </Card>

      <Card title="Texto e rolagem">
        <Toggle label="Letras embaralhando nos títulos" checked={a.scramble} onChange={(v) => setAnim({ scramble: v })} />
        <Toggle label="Palavras entrando uma a uma" checked={a.wordReveal} onChange={(v) => setAnim({ wordReveal: v })} />
        <Toggle label="Elementos sobem ao rolar a página" checked={a.scrollReveal} onChange={(v) => setAnim({ scrollReveal: v })} />
        <Toggle label="Faixa vermelha rolando (marquee)" checked={a.marquee} onChange={(v) => setAnim({ marquee: v })} />
        <Field label="Texto da faixa"><Text value={a.marqueeText} onChange={(v) => setAnim({ marqueeText: v })} /></Field>
        <button onClick={() => setAnim(DEFAULT_STATE.settings.anim)} className="text-xs uppercase tracking-widest text-white/50 underline hover:text-white">Restaurar animações padrão</button>
      </Card>
    </div>
  );
}

/* ---------- BACKUP / PUBLICAR / SEGURANÇA ---------- */
export function BackupTab() {
  const { state, source, replace, resetToPublished } = useStore();
  const fileRef = useRef<HTMLInputElement>(null);
  const size = (JSON.stringify(state).length / 1024 / 1024).toFixed(2);

  const importFile = async (f?: File) => {
    if (!f) return;
    try { replace(JSON.parse(await f.text())); alert('Catálogo importado!'); } catch { alert('Arquivo inválido.'); }
  };


  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Publicar alterações" hint="Com Supabase configurado e sessão de administrador válida, as edições são salvas no banco compartilhado. Sem ele, esta versão local só salva neste navegador.">
        <ol className="list-decimal space-y-1 pl-5 text-sm text-white/70">
          <li>Clique em <b>Exportar catalog.json</b>.</li>
          <li>Coloque o arquivo na pasta <code className="text-brisa">public/</code> do projeto (substitui o anterior).</li>
          <li>Rode <code className="text-brisa">npm run build</code> e publique a pasta <code className="text-brisa">dist/</code>.</li>
        </ol>
        <button onClick={() => download('catalog.json', JSON.stringify(state))} className="rounded-full bg-brisa px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:brightness-110">Exportar catalog.json</button>
        <p className="text-xs text-white/40">Origem atual dos dados: <b className="text-white/70">{source}</b> · tamanho: {size} MB</p>
      </Card>

      <Card title="Importar / restaurar">
        <button onClick={() => fileRef.current?.click()} className="rounded-full border border-white/25 px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:bg-white/10">Importar catalog.json</button>
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { void importFile(e.target.files?.[0]); e.target.value = ''; }} />
        <button onClick={() => { if (confirm('Descartar as alterações locais e voltar ao catálogo publicado?')) void resetToPublished(); }} className="block rounded-full border border-white/25 px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:bg-white/10">Voltar ao catálogo publicado</button>
        <button onClick={() => { if (confirm('Apagar tudo e voltar aos produtos de exemplo?')) replace(DEFAULT_STATE); }} className="block text-xs uppercase tracking-widest text-brisa underline">Restaurar produtos de exemplo</button>
      </Card>

      <Card title="Segurança administrativa" hint="A senha não é alterada neste painel. Configure autenticação Supabase e use a rota restrita /adminsupremo.">
        <p className="text-sm text-white/70">O modo local de demonstração não protege o painel em produção. Configure as variáveis de ambiente e promova a conta administrativa pelo SQL do Supabase.</p>
        <a href="/adminsupremo" className="inline-block rounded-full bg-brisa px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white">Abrir Admin Supremo</a>
      </Card>
    </div>
  );
}
