import { useState } from 'react';
import { Lock } from 'lucide-react';
import { useStore } from '../store';
import { sha256 } from '../lib/util';
import { supabase, supabaseConfigured } from '../lib/supabase';

export default function Login({ onOk }: { onOk: () => void }) {
  const { state } = useStore();
  const [pw, setPw] = useState('');
  const [email, setEmail] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (supabaseConfigured && supabase) {
        if (!email.trim()) throw new Error('Informe o e-mail do administrador.');
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
        if (error || !data.user) throw new Error('E-mail ou senha incorretos.');
        const { data: profile, error: roleError } = await supabase.from('profiles').select('role').eq('id', data.user.id).maybeSingle();
        if (roleError || profile?.role !== 'admin') { await supabase.auth.signOut(); throw new Error('Esta conta não tem permissão de administrador.'); }
        sessionStorage.setItem('brisa-admin', 'supabase'); onOk();
      } else {
        const h = await sha256(pw); await new Promise((r) => setTimeout(r, 300));
        if (h === state.settings.adminPasswordHash) { sessionStorage.setItem('brisa-admin', 'local-demo'); onOk(); }
        else setErr('Senha incorreta.');
      }
    } catch (e:any) { setErr(e.message || 'Falha ao autenticar.'); }
    setBusy(false);
  };

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden bg-ink p-4">
      <div className="smoke-blob" style={{ left: '-20vw', top: '10vh' }} />
      <div className="smoke-blob" style={{ right: '-25vw', top: '40vh', animationDelay: '-7s' }} />
      <form onSubmit={submit} className="relative z-10 w-full max-w-sm rounded-3xl border border-brisa/40 bg-black/80 p-8 backdrop-blur">
        {state.settings.logo && <img src={state.settings.logo} alt="" className="mx-auto mb-4 h-16 w-auto" />}
        {!supabaseConfigured && <p className="mt-3 text-xs text-amber-300">Modo local de demonstração: configure o Supabase antes de publicar para proteger o painel de verdade.</p>}
        <h1 className="flex items-center justify-center gap-2 font-display text-3xl uppercase tracking-widest text-white"><Lock size={22} className="text-brisa" /> Painel Admin</h1>
        {supabaseConfigured && <input autoFocus type="email" value={email} onChange={(e) => { setEmail(e.target.value); setErr(''); }} placeholder="E-mail do administrador" className="mt-6 w-full rounded-lg border border-white/15 bg-black px-4 py-3 text-white outline-none focus:border-brisa" />}
        <input autoFocus={!supabaseConfigured} type="password" value={pw} onChange={(e) => { setPw(e.target.value); setErr(''); }} placeholder="Senha" className="mt-6 w-full rounded-lg border border-white/15 bg-black px-4 py-3 text-white outline-none focus:border-brisa" />
        {err && <p className="mt-2 text-sm text-brisa">{err}</p>}
        <button disabled={busy} className="mt-5 w-full rounded-full bg-brisa py-3 text-sm font-bold uppercase tracking-widest text-white hover:brightness-110 disabled:opacity-60">{busy ? 'Verificando…' : 'Entrar'}</button>
        <a href="/" className="mt-4 block text-center text-xs uppercase tracking-widest text-white/40 hover:text-white">← Voltar ao site</a>
      </form>
    </div>
  );
}
