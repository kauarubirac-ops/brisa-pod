import { useState } from 'react';
import { ArrowDown, ArrowUp, Eye, EyeOff, Minus, Pencil, Plus, Trash2, X } from 'lucide-react';
import { useStore } from '../store';
import type { Product } from '../types';
import { podSvg } from '../defaults';
import { uid, money } from '../lib/util';
import { Area, ColorInput, Field, FileUpload, ImageUpload, NumberInput, Text, Toggle } from './ui';

const blank = (): Product => ({
  id: uid(), name: 'NOVO PRODUTO', category: 'Pods descartáveis', flavor: '', puffs: '', description: '', price: 0, stock: 0,
  image: podSvg('#E10B24', '#7a0010', 'NOVO'), model: '', bg: '#B10F26', published: true, featured: true,
});

function ProductForm({ initial, categories, onSave, onCancel }: { initial: Product; categories: string[]; onSave: (p: Product) => void; onCancel: () => void }) {
  const [p, setP] = useState<Product>(initial);
  const set = <K extends keyof Product>(k: K, v: Product[K]) => setP((o) => ({ ...o, [k]: v }));
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-auto bg-black/80 p-4 backdrop-blur-sm">
      <div className="my-6 w-full max-w-3xl rounded-2xl border border-brisa/40 bg-ink p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-3xl uppercase text-white">{initial.name === 'NOVO PRODUTO' ? 'Novo produto' : 'Editar produto'}</h3>
          <button onClick={onCancel} className="rounded-full border border-white/20 p-2 text-white hover:bg-white/10" aria-label="Fechar"><X size={16} /></button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Nome"><Text value={p.name} onChange={(v) => set('name', v)} /></Field>
          <Field label="Categoria">
            <Text value={p.category} onChange={(v) => set('category', v)} />
            <div className="mt-1 flex flex-wrap gap-1">{categories.map((c) => <button key={c} type="button" onClick={() => set('category', c)} className="rounded-full border border-white/15 px-2 py-0.5 text-[10px] text-white/60 hover:border-brisa hover:text-white">{c}</button>)}</div>
          </Field>
          <Field label="Sabor"><Text value={p.flavor} onChange={(v) => set('flavor', v)} /></Field>
          <Field label="Puffs / detalhe"><Text value={p.puffs} onChange={(v) => set('puffs', v)} placeholder="10.000 puffs" /></Field>
          <Field label="Preço"><NumberInput value={p.price} step={0.1} onChange={(v) => set('price', v)} /></Field>
          <Field label="Quantidade em estoque"><NumberInput value={p.stock} onChange={(v) => set('stock', Math.max(0, Math.floor(v)))} /></Field>
          <div className="sm:col-span-2"><Field label="Descrição"><Area value={p.description} onChange={(v) => set('description', v)} /></Field></div>
          <div className="sm:col-span-2">
            <Field label="Foto do produto" hint="PNG/WebP com fundo transparente fica melhor no carrossel.">
              <ImageUpload value={p.image} onChange={(v) => set('image', v)} checker />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Modelo 3D (.glb) — opcional" hint="Aparece no botão “Ver em 3D” e, se ativado no Hero, no centro do carrossel.">
              <FileUpload value={p.model} onChange={(v) => set('model', v)} accept=".glb,.gltf,model/gltf-binary" label="Enviar .glb" />
            </Field>
          </div>
          <Field label="Cor de fundo do hero (quando está no centro)"><ColorInput value={p.bg} onChange={(v) => set('bg', v)} /></Field>
          <div className="space-y-2">
            <Toggle label="Publicado no site" checked={p.published} onChange={(v) => set('published', v)} />
            <Toggle label="Aparece no carrossel do hero" checked={p.featured} onChange={(v) => set('featured', v)} />
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <button onClick={onCancel} className="rounded-full border border-white/20 px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:bg-white/10">Cancelar</button>
          <button onClick={() => onSave(p)} className="rounded-full bg-brisa px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:brightness-110">Salvar</button>
        </div>
      </div>
    </div>
  );
}

export default function ProductsTab() {
  const { state, update } = useStore();
  const [editing, setEditing] = useState<Product | null>(null);
  const [q, setQ] = useState('');
  const cats = Array.from(new Set(state.products.map((p) => p.category).filter(Boolean)));
  const cur = state.settings.currency;

  const patch = (id: string, fn: (p: Product) => Product) => update((s) => ({ ...s, products: s.products.map((p) => (p.id === id ? fn(p) : p)) }));
  const move = (i: number, d: -1 | 1) => update((s) => {
    const arr = [...s.products]; const j = i + d;
    if (j < 0 || j >= arr.length) return s;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    return { ...s, products: arr };
  });
  const save = (p: Product) => {
    update((s) => (s.products.some((x) => x.id === p.id) ? { ...s, products: s.products.map((x) => (x.id === p.id ? p : x)) } : { ...s, products: [...s.products, p] }));
    setEditing(null);
  };
  const remove = (p: Product) => { if (confirm(`Excluir "${p.name}"?`)) update((s) => ({ ...s, products: s.products.filter((x) => x.id !== p.id) })); };

  const shown = state.products.filter((p) => `${p.name} ${p.category}`.toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar produto…" className="w-full rounded-lg border border-white/15 bg-black px-3 py-2 text-sm text-white outline-none focus:border-brisa sm:max-w-xs" />
        <button onClick={() => setEditing(blank())} className="flex items-center justify-center gap-2 rounded-full bg-brisa px-6 py-2.5 text-sm font-bold uppercase tracking-widest text-white hover:brightness-110"><Plus size={16} /> Novo produto</button>
      </div>

      <div className="space-y-3">
        {shown.map((p) => {
          const i = state.products.findIndex((x) => x.id === p.id);
          return (
            <div key={p.id} className={`flex flex-wrap items-center gap-4 rounded-2xl border bg-white/[0.03] p-3 ${p.published ? 'border-white/10' : 'border-white/5 opacity-60'}`}>
              <div className="grid h-20 w-16 shrink-0 place-items-center rounded-lg" style={{ background: p.bg }}>
                <img src={p.image} alt="" className="max-h-full max-w-full object-contain" />
              </div>
              <div className="min-w-[140px] flex-1">
                <p className="font-display text-xl uppercase text-white">{p.name}</p>
                <p className="text-xs text-white/50">{p.category} · {money(p.price, cur)}{p.model ? ' · 3D' : ''}{p.featured ? ' · hero' : ''}</p>
              </div>
              <div className="flex items-center gap-1 rounded-full border border-white/15 p-1" title="Estoque">
                <button onClick={() => patch(p.id, (x) => ({ ...x, stock: Math.max(0, x.stock - 1) }))} className="rounded-full p-1.5 text-white hover:bg-white/10" aria-label="-1"><Minus size={14} /></button>
                <input type="number" min={0} value={p.stock} onChange={(e) => patch(p.id, (x) => ({ ...x, stock: Math.max(0, Math.floor(Number(e.target.value) || 0)) }))} className="w-14 bg-transparent text-center text-sm font-bold text-white outline-none" />
                <button onClick={() => patch(p.id, (x) => ({ ...x, stock: x.stock + 1 }))} className="rounded-full p-1.5 text-white hover:bg-white/10" aria-label="+1"><Plus size={14} /></button>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => move(i, -1)} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Subir"><ArrowUp size={16} /></button>
                <button onClick={() => move(i, 1)} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Descer"><ArrowDown size={16} /></button>
                <button onClick={() => patch(p.id, (x) => ({ ...x, published: !x.published }))} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Publicar/ocultar">{p.published ? <Eye size={16} /> : <EyeOff size={16} />}</button>
                <button onClick={() => setEditing(p)} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Editar"><Pencil size={16} /></button>
                <button onClick={() => remove(p)} className="rounded-lg p-2 text-brisa hover:bg-brisa/10" aria-label="Excluir"><Trash2 size={16} /></button>
              </div>
            </div>
          );
        })}
        {shown.length === 0 && <p className="py-10 text-center text-white/40">Nenhum produto.</p>}
      </div>

      {editing && <ProductForm initial={editing} categories={cats} onSave={save} onCancel={() => setEditing(null)} />}
    </div>
  );
}
