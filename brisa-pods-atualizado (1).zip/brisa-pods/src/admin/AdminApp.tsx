import { useEffect, useState } from 'react';
import { Boxes, Clapperboard, DatabaseBackup, ExternalLink, LogOut, Palette, Sparkles } from 'lucide-react';
import Login from './Login';
import ProductsTab from './ProductsTab';
import { AnimTab, BackupTab, BrandTab, HeroTab } from './SettingsTabs';
import { useStore } from '../store';
import OrdersTab from './OrdersTab';
import { supabase } from '../lib/supabase';

const TABS = [
  { id: 'products', label: 'Produtos & estoque', icon: Boxes },
  { id: 'orders', label: 'Pedidos', icon: Boxes },
  { id: 'reservations', label: 'Reservas', icon: Boxes },
  { id: 'hero', label: 'Hero & 3D', icon: Clapperboard },
  { id: 'brand', label: 'Marca, cores & vendas', icon: Palette },
  { id: 'anim', label: 'Animações', icon: Sparkles },
  { id: 'backup', label: 'Publicar & segurança', icon: DatabaseBackup },
] as const;
type TabId = (typeof TABS)[number]['id'] | 'hero' | 'brand' | 'anim' | 'backup';

export default function AdminApp() {
  const [authed, setAuthed] = useState(sessionStorage.getItem('brisa-admin') === 'local-demo');
  const [tab, setTab] = useState<TabId>('products');
  const { state } = useStore();
  useEffect(() => { let active = true; if (supabase && sessionStorage.getItem('brisa-admin') === 'supabase') { void (async () => { const { data } = await supabase.auth.getSession(); if (!data.session) { sessionStorage.removeItem('brisa-admin'); if (active) setAuthed(false); return; } const { data: profile } = await supabase.from('profiles').select('role').eq('id', data.session.user.id).maybeSingle(); if (active && profile?.role === 'admin') setAuthed(true); else { await supabase.auth.signOut(); sessionStorage.removeItem('brisa-admin'); if (active) setAuthed(false); } })(); } return () => { active = false; }; }, []);

  if (!authed) return <Login onOk={() => setAuthed(true)} />;

  return (
    <div className="min-h-screen bg-ink text-white">
      <header className="sticky top-0 z-40 flex items-center justify-between gap-3 border-b border-white/10 bg-black/90 px-4 py-3 backdrop-blur sm:px-8">
        <div className="flex items-center gap-3">
          {state.settings.logo && <img src={state.settings.logo} alt="" className="h-9 w-auto" />}
          <span className="hidden font-display text-xl uppercase tracking-widest sm:inline">Painel Admin</span>
        </div>
        <div className="flex items-center gap-2">
          <a href="/" target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-xs font-bold uppercase tracking-widest hover:bg-white/10"><ExternalLink size={14} /> Ver site</a>
          <button onClick={() => { sessionStorage.removeItem('brisa-admin'); void supabase?.auth.signOut(); setAuthed(false); }} className="flex items-center gap-2 rounded-full bg-brisa px-4 py-2 text-xs font-bold uppercase tracking-widest hover:brightness-110"><LogOut size={14} /> Sair</button>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-6 sm:px-8">
        <nav className="mb-6 flex gap-2 overflow-x-auto pb-2">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-widest transition ${tab === t.id ? 'border-brisa bg-brisa text-white' : 'border-white/15 text-white/70 hover:border-white/40'}`}>
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </nav>
        <p className="mb-5 text-xs text-white/40">Alterações são salvas automaticamente e aparecem no site ao recarregar a página.</p>
        {tab === 'products' && <ProductsTab />}
        {tab === 'orders' && <OrdersTab kind="orders" />}
        {tab === 'reservations' && <OrdersTab kind="reservations" />}
        {tab === 'hero' && <HeroTab />}
        {tab === 'brand' && <BrandTab />}
        {tab === 'anim' && <AnimTab />}
        {tab === 'backup' && <BackupTab />}
      </div>
    </div>
  );
}
