import type { Settings } from '../types';

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function hexToRgbTriplet(hex: string): string {
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h.padEnd(6, '0');
  const n = parseInt(full.slice(0, 6), 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

export function money(value: number, currency: string): string {
  return `${currency} ${value.toFixed(2).replace('.', ',')}`;
}

export function whatsappLink(s: Settings, productName: string): string | null {
  const digits = s.whatsapp.replace(/\D/g, '');
  if (!digits) return null;
  const msg = s.whatsappMessage.replace('{produto}', productName);
  return `https://wa.me/${digits}?text=${encodeURIComponent(msg)}`;
}

export const EASINGS: Record<string, string> = {
  suave: 'cubic-bezier(0.4, 0, 0.2, 1)',
  rápido: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
  elástico: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
  cinematográfico: 'cubic-bezier(0.77, 0, 0.175, 1)',
  linear: 'linear',
};

export function download(filename: string, content: string, mime = 'application/json') {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
