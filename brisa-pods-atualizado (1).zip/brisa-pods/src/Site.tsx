import { useState } from 'react';
import { useStore } from './store';
import type { Product } from './types';
import { hexToRgbTriplet } from './lib/util';
import Hero from './components/Hero';
import Catalog from './components/Catalog';
import ProductModal from './components/ProductModal';
import AgeGate from './components/AgeGate';
import Cursor from './components/Cursor';
import FluidTrail from './components/FluidTrail';
import SmokeCanvas from './components/SmokeCanvas';
import { Reveal, ScrambleText } from './components/Effects';

export default function Site() {
  const { state } = useStore();
  const s = state.settings;
  const a = s.anim;
  const [open, setOpen] = useState<Product | null>(null);
  const red = hexToRgbTriplet(s.colors.red);
  const marquee = (a.marqueeText + ' ').repeat(8);

  return (
    <div className="relative min-h-screen bg-ink text-white">
      {/* fundo global: GIF de fumaça + canvas + blobs CSS */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        {a.gifBg && s.bgGif && <img src={s.bgGif} alt="" className="h-full w-full object-cover mix-blend-screen" style={{ opacity: a.gifOpacity / 100 }} />}
        <div className="smoke-blob" style={{ left: '-25vw', top: '15vh' }} />
        <div className="smoke-blob" style={{ right: '-30vw', top: '45vh', animationDelay: '-6s', animationDuration: '23s' }} />
        {a.smokeCanvas && <SmokeCanvas color={red} intensity={a.smokeIntensity * 0.6} alpha={0.25} />}
      </div>

      <div className="relative z-10">
        <div className="absolute right-4 top-4 z-30 sm:right-8 sm:top-6"><a href="/conta" className="rounded-full border border-white/25 bg-black/70 px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur hover:border-brisa sm:text-xs">Minha conta</a></div>
        <Hero onOpen={setOpen} />

        {a.marquee && (
          <div className="relative overflow-hidden border-y border-white/10 bg-brisa py-3 -rotate-1 scale-105">
            <div className="flex w-max animate-marquee whitespace-nowrap font-display text-2xl uppercase tracking-widest text-white">
              <span>{marquee}</span><span>{marquee}</span>
            </div>
          </div>
        )}

        <Catalog onOpen={setOpen} />

        <section id="marca" className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-20 sm:px-8 md:grid-cols-2">
          <Reveal enabled={a.scrollReveal}>
            <div className="rounded-3xl border border-white/10 bg-black/40 p-8">
              {s.logo ? <img src={s.logo} alt={s.brandName} className="mx-auto w-full max-w-md" draggable={false} /> : <p className="text-center font-display text-6xl">{s.brandName}</p>}
            </div>
          </Reveal>
          <Reveal enabled={a.scrollReveal} delay={120}>
            <p className="mb-3 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-brisa"><i className="inline-block h-px w-10 bg-brisa" /> Sobre a identidade</p>
            <h2 className="font-display text-5xl uppercase leading-[1.05] sm:text-7xl"><ScrambleText text={s.aboutTitle} enabled={a.scramble} /></h2>
            <p className="mt-5 max-w-lg text-white/70">{s.aboutText}</p>
            <div className="mt-6 h-1 w-24 bg-brisa" />
          </Reveal>
        </section>

        <footer className="border-t border-white/10 px-4 py-10 sm:px-8">
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 text-xs uppercase tracking-widest text-white/50 sm:flex-row">
            {s.logo && <img src={s.logo} alt={s.brandName} className="h-12 w-auto" />}
            <span>© {new Date().getFullYear()} {s.brandName}</span>
            <span>{s.footerText}</span>
          </div>
        </footer>
      </div>

      {a.trail && <FluidTrail color={red} />}
      {a.cursor && <Cursor />}
      {open && <ProductModal product={open} onClose={() => setOpen(null)} />}
      <AgeGate />
    </div>
  );
}
