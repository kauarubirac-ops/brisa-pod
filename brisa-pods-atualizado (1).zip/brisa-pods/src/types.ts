export interface Product {
  id: string;
  name: string;
  category: string;
  flavor: string;
  puffs: string;
  description: string;
  price: number;
  stock: number;
  image: string; // URL ou data URL (PNG/WebP transparente fica melhor)
  model: string; // data URL de um .glb (opcional)
  bg: string; // cor de fundo do hero quando este produto está no centro
  published: boolean;
  featured: boolean; // aparece no carrossel do hero
}

export interface AnimSettings {
  carouselMs: number;
  easing: string;
  autoplay: boolean;
  autoplayMs: number;
  float: boolean;
  smokeCanvas: boolean;
  smokeIntensity: number;
  smokeFront: boolean;
  gifBg: boolean;
  gifOpacity: number;
  grain: boolean;
  grainOpacity: number;
  cursor: boolean;
  trail: boolean;
  spotlight: boolean;
  tilt: boolean;
  scramble: boolean;
  wordReveal: boolean;
  scrollReveal: boolean;
  ghostParallax: boolean;
  marquee: boolean;
  marqueeText: string;
  magnetic: boolean;
}

export interface Settings {
  brandName: string;
  logo: string;
  logoHeight: number;
  ghostText: string;
  heroLabel: string;
  heroText: string;
  ctaLabel: string;
  catalogTitle: string;
  catalogSubtitle: string;
  aboutTitle: string;
  aboutText: string;
  footerText: string;
  whatsapp: string;
  whatsappMessage: string;
  currency: string;
  ageGate: boolean;
  showStock: boolean;
  colors: { red: string; black: string; ghost: string };
  heroModel: string;
  useModelInHero: boolean;
  bgGif: string;
  anim: AnimSettings;
  adminPasswordHash: string;
}

export interface SiteState {
  version: number;
  updatedAt: number;
  settings: Settings;
  products: Product[];
}
