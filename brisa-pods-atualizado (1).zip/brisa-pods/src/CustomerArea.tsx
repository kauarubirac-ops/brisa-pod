import { useEffect, useState } from 'react';
import { supabase, supabaseConfigured } from './lib/supabase';
import { useStore } from './store';
import { money } from './lib/util';

export default function CustomerArea() {
  const { state } = useStore();
  const [session, setSession] = useState<any>(null);
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [form, setForm] = useState({ email:'', password:'', full_name:'', cpf:'', phone:'', address:'' });
  const [message, setMessage] = useState('');
  const [orders, setOrders] = useState<any[]>([]);
  const [reservations, setReservations] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const reserveId = new URLSearchParams(location.search).get('reserve');
  const patch = (k:string,v:string) => setForm(p=>({...p,[k]:v}));

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_e,s)=>setSession(s));
    return ()=>subscription.unsubscribe();
  },[]);
  const loadMine = async () => {
    if (!supabase || !session) return;
    const [{data:o},{data:r}] = await Promise.all([
      supabase.from('orders').select('*').order('created_at',{ascending:false}),
      supabase.from('reservations').select('*').order('created_at',{ascending:false}),
    ]);
    setOrders(o??[]); setReservations(r??[]);
  };
  useEffect(()=>{void loadMine();},[session]);

  const submit = async (e:React.FormEvent) => {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage('');
    try {
      if (mode==='signup') {
        const {data,error}=await supabase.auth.signUp({email:form.email,password:form.password,options:{data:{full_name:form.full_name,cpf:form.cpf,phone:form.phone,address:form.address}}});
        if(error) throw error;
        if(data.session && data.user) {
          const {error:pe}=await supabase.from('profiles').update({full_name:form.full_name,cpf:form.cpf,phone:form.phone,address:form.address}).eq('id',data.user.id);
          if(pe) throw pe;
        }
        setMessage('Cadastro enviado. Confirme seu e-mail, se solicitado, e entre na conta.');
      } else {
        const {error}=await supabase.auth.signInWithPassword({email:form.email,password:form.password}); if(error) throw error;
      }
    } catch(err:any){setMessage(err.message||'Não foi possível concluir.');} finally{setBusy(false);}
  };
  const google = async()=>{if(!supabase)return; const {error}=await supabase.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+'/conta'}});if(error)setMessage(error.message);};
  const makeRequest = async (productId:string, kind:'orders'|'reservations') => {
    if(!supabase||!session)return;
    const p=state.products.find(x=>x.id===productId); if(!p)return;
    const quantity=Number(prompt(`Quantas unidades de ${p.name}?`,'1')); if(!Number.isInteger(quantity)||quantity<1)return;
    setBusy(true);setMessage('');
    const payload=kind==='orders'?{customer_id:session.user.id,product_id:p.id,product_name:p.name,quantity,unit_price:p.price}:{customer_id:session.user.id,product_id:p.id,product_name:p.name,quantity};
    const {error}=await supabase.from(kind).insert(payload);
    if(error)setMessage(error.message);else{setMessage(kind==='orders'?'Pedido registrado. O pagamento será validado pela equipe.':'Reserva registrada. Avisaremos quando houver reposição.');await loadMine();}
    setBusy(false);
  };
  const card='rounded-2xl border border-white/10 bg-white/[0.04] p-5';
  return <main className="min-h-screen bg-ink px-4 py-8 text-white sm:px-8"><div className="mx-auto max-w-5xl">
    <a href="/" className="text-xs uppercase tracking-widest text-brisa">← Voltar à Brisa Pods</a>
    <h1 className="my-6 font-display text-4xl uppercase sm:text-6xl">Área do cliente</h1>
    {!supabaseConfigured ? <div className={card}><h2 className="text-xl font-bold">Autenticação ainda não configurada</h2><p className="mt-2 text-white/70">Adicione as chaves do Supabase ao arquivo .env para ativar cadastro, login, pedidos e reservas compartilhados.</p></div> : !session ? <form onSubmit={submit} className={`${card} mx-auto max-w-xl space-y-3`}>
      <div className="flex gap-2"><button type="button" onClick={()=>setMode('login')} className={`rounded-full px-4 py-2 text-sm ${mode==='login'?'bg-brisa':'border border-white/20'}`}>Entrar</button><button type="button" onClick={()=>setMode('signup')} className={`rounded-full px-4 py-2 text-sm ${mode==='signup'?'bg-brisa':'border border-white/20'}`}>Criar conta</button></div>
      {mode==='signup'&&<><input required placeholder="Nome completo" value={form.full_name} onChange={e=>patch('full_name',e.target.value)} className="w-full rounded-lg bg-black p-3"/><input required placeholder="CPF" value={form.cpf} onChange={e=>patch('cpf',e.target.value)} className="w-full rounded-lg bg-black p-3"/><input required placeholder="Telefone com DDD" value={form.phone} onChange={e=>patch('phone',e.target.value)} className="w-full rounded-lg bg-black p-3"/><input required placeholder="Endereço completo" value={form.address} onChange={e=>patch('address',e.target.value)} className="w-full rounded-lg bg-black p-3"/> </>}
      <input required type="email" placeholder="E-mail" value={form.email} onChange={e=>patch('email',e.target.value)} className="w-full rounded-lg bg-black p-3"/><input required minLength={8} type="password" placeholder="Senha (mínimo 8 caracteres)" value={form.password} onChange={e=>patch('password',e.target.value)} className="w-full rounded-lg bg-black p-3"/>
      <button disabled={busy} className="w-full rounded-full bg-brisa p-3 font-bold">{busy?'Aguarde…':mode==='login'?'Entrar com e-mail':'Criar cadastro'}</button><button type="button" onClick={google} className="w-full rounded-full border border-white/20 p-3">Continuar com Google</button>{message&&<p className="text-sm text-brisa">{message}</p>}
    </form> : <div className="space-y-6"><div className={card}><div className="flex flex-wrap items-center justify-between gap-3"><p>Conectado como <strong>{session.user.email}</strong></p><button onClick={()=>supabase?.auth.signOut()} className="rounded-full border border-white/20 px-4 py-2 text-sm">Sair</button></div></div>
      {reserveId&&<div className={card}><p>Você está tentando reservar: <strong>{state.products.find(p=>p.id===reserveId)?.name??'Produto'}</strong></p><button disabled={busy} onClick={()=>makeRequest(reserveId,'reservations')} className="mt-3 rounded-full bg-brisa px-5 py-3 font-bold">Confirmar reserva</button></div>}
      <section className={card}><h2 className="mb-4 text-2xl font-bold">Produtos</h2><div className="grid gap-3 sm:grid-cols-2">{state.products.filter(p=>p.published).map(p=><div key={p.id} className="rounded-xl border border-white/10 p-4"><p className="font-bold">{p.name}</p><p className="text-sm text-white/60">{money(p.price,state.settings.currency)} · estoque: {p.stock}</p><button disabled={busy} onClick={()=>makeRequest(p.id,p.stock>0?'orders':'reservations')} className="mt-3 rounded-full bg-brisa px-4 py-2 text-sm font-bold">{p.stock>0?'Solicitar pedido':'Reservar produto'}</button></div>)}</div></section>
      <section className={card}><h2 className="mb-3 text-2xl font-bold">Meus pedidos</h2>{orders.length?orders.map(o=><p key={o.id} className="border-b border-white/10 py-3">{o.product_name} × {o.quantity} — {o.status==='delivered'?'Finalizado':o.status==='cancelled'?'Cancelado':'Novo'} · Pagamento: {o.payment_status==='paid'?'Pago':o.payment_status==='unpaid'?'Não pago':'Pendente'}</p>):<p className="text-white/50">Nenhum pedido ainda.</p>}</section>
      <section className={card}><h2 className="mb-3 text-2xl font-bold">Minhas reservas</h2>{reservations.length?reservations.map(r=><p key={r.id} className="border-b border-white/10 py-3">{r.product_name} × {r.quantity} — {r.status==='notified'?'Estoque reposto / notificado':r.status==='converted'?'Convertida em pedido':r.status==='cancelled'?'Cancelada':'Aguardando reposição'}</p>):<p className="text-white/50">Nenhuma reserva ainda.</p>}</section>
    </div>}
  </div></main>;
}
