import type { Product, SiteState } from './types';

/** Gera um "pod" ilustrado em SVG (transparente) para os produtos de exemplo. */
export function podSvg(c1: string, c2: string, label: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 500"><defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stop-color="${c1}"/><stop offset=".55" stop-color="${c2}"/><stop offset="1" stop-color="${c1}"/></linearGradient><linearGradient id="s" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".22" stop-color="#fff" stop-opacity=".38"/><stop offset=".4" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><rect x="112" y="6" width="76" height="40" rx="14" fill="#1b1b1b"/><rect x="95" y="30" width="110" height="60" rx="22" fill="#111"/><rect x="60" y="76" width="180" height="410" rx="48" fill="url(#g)"/><rect x="60" y="76" width="180" height="410" rx="48" fill="url(#s)"/><rect x="132" y="440" width="36" height="8" rx="4" fill="#fff" opacity=".9"/><text x="150" y="280" font-family="Arial Black,Impact,sans-serif" font-size="30" font-weight="900" fill="#fff" text-anchor="middle" transform="rotate(-90 150 280)" letter-spacing="3">${label}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const demo = (
  id: string, name: string, flavor: string, puffs: string, price: number, stock: number,
  c1: string, c2: string, bg: string, description: string, category = 'Pods descartáveis',
): Product => ({
  id, name, category, flavor, puffs, description, price, stock,
  image: podSvg(c1, c2, name.replace('BRISA ', '')),
  model: '', bg, published: true, featured: true,
});

// SHA-256 de "pods123"
export const DEFAULT_PASSWORD_HASH = 'f42a69d46ad13898fccf427628d00c730099a3776e8744fbee5bfdc743f253b4';

export const DEFAULT_STATE: SiteState = {
  version: 1,
  updatedAt: 0,
  settings: {
    brandName: 'BRISA PODS',
    logo: '/assets/logo.png',
    logoHeight: 56,
    ghostText: 'BRISA',
    heroLabel: 'BRISA PODS',
    heroText: 'Identidade forte. Estética noturna. Escolha o seu e veja o catálogo completo.',
    ctaLabel: 'Ver catálogo',
    catalogTitle: 'CATÁLOGO',
    catalogSubtitle: 'Escolha seu favorito. Estoque atualizado em tempo real pelo painel.',
    aboutTitle: 'FEITO PARA MARCAR PRESENÇA.',
    aboutText: 'Vermelho intenso sobre preto profundo, com uma linguagem gráfica direta e sem excessos. BRISA PODS é fumaça, contraste e atitude.',
    footerText: 'IDENTIDADE EM MOVIMENTO.',
    whatsapp: '',
    whatsappMessage: 'Olá! Tenho interesse no produto: {produto}',
    currency: 'R$',
    ageGate: true,
    showStock: true,
    colors: { red: '#E10B24', black: '#0A0A0A', ghost: '#FFFFFF' },
    heroModel: '',
    useModelInHero: false,
    bgGif: '/assets/fumaca.gif',
    anim: {
      carouselMs: 650,
      easing: 'suave',
      autoplay: false,
      autoplayMs: 5000,
      float: true,
      smokeCanvas: true,
      smokeIntensity: 60,
      smokeFront: true,
      gifBg: true,
      gifOpacity: 22,
      grain: true,
      grainOpacity: 40,
      cursor: true,
      trail: true,
      spotlight: true,
      tilt: true,
      scramble: true,
      wordReveal: true,
      scrollReveal: true,
      ghostParallax: true,
      marquee: true,
      marqueeText: 'BRISA PODS ✦ FUMAÇA VERMELHA ✦ NOVOS SABORES ✦ ',
      magnetic: true,
    },
    adminPasswordHash: DEFAULT_PASSWORD_HASH,
  },
  products: [
    demo('p1', 'BRISA ICE', 'Menta gelada', '10.000 puffs', 89.9, 24, '#E10B24', '#7a0010', '#B10F26', 'Sabor gelado e intenso, refrescância do início ao fim.'),
    demo('p2', 'BRISA NIGHT', 'Frutas vermelhas', '12.000 puffs', 99.9, 15, '#1a1a1a', '#000000', '#0B0B0B', 'Noite em cada tragada: blend de frutas vermelhas e fundo adocicado.'),
    demo('p3', 'BRISA FIRE', 'Morango & canela', '10.000 puffs', 94.9, 8, '#ff2a3d', '#a30018', '#7A0A1A', 'Doce com um toque de calor. A cara da marca.'),
    demo('p4', 'BRISA WHITE', 'Uva branca', '8.000 puffs', 79.9, 0, '#f2f2f2', '#b9b9b9', '#C8102E', 'Leve, limpo e frutado. Edição branca.'),
  ],
};
