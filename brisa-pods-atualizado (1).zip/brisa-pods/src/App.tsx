import { useEffect, useState } from 'react';
import { useStore } from './store';
import Site from './Site';
import AdminApp from './admin/AdminApp';
import CustomerArea from './CustomerArea';
import AdminSupremo from './admin/AdminSupremo';

function usePath() {
  const [path, setPath] = useState(window.location.pathname);
  useEffect(() => {
    const on = () => setPath(window.location.pathname);
    window.addEventListener('popstate', on);
    return () => window.removeEventListener('popstate', on);
  }, []);
  return path;
}

export default function App() {
  const path = usePath();
  const { loaded } = useStore();
  if (!loaded) {
    return <div className="grid min-h-screen place-items-center bg-ink font-display text-3xl tracking-widest text-brisa">BRISA…</div>;
  }
  const route = path.replace(/\/+$/, '') || '/';
  if (route === '/conta') return <CustomerArea />;
  if (route === '/adminsupremo') return <AdminSupremo />;
  return route.startsWith('/admin') ? <AdminApp /> : <Site />;
}
