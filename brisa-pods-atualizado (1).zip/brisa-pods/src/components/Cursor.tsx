import { useEffect, useRef } from 'react';

/** Cursor personalizado: ponto instantâneo + anel com atraso (inércia). */
export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!window.matchMedia('(pointer: fine)').matches) return;
    document.body.classList.add('custom-cursor');
    let x = -100, y = -100, rx = -100, ry = -100, raf = 0, big = false;
    const onMove = (e: PointerEvent) => {
      x = e.clientX; y = e.clientY;
      const t = e.target as HTMLElement | null;
      big = !!t?.closest('a,button,[data-hover],input,select,textarea');
    };
    const loop = () => {
      rx += (x - rx) * 0.16; ry += (y - ry) * 0.16;
      if (dot.current) dot.current.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%)`;
      if (ring.current) ring.current.style.transform = `translate(${rx}px,${ry}px) translate(-50%,-50%) scale(${big ? 1.9 : 1})`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener('pointermove', onMove);
    raf = requestAnimationFrame(loop);
    return () => {
      document.body.classList.remove('custom-cursor');
      cancelAnimationFrame(raf);
      window.removeEventListener('pointermove', onMove);
    };
  }, []);

  return (
    <>
      <div ref={ring} className="pointer-events-none fixed left-0 top-0 z-[200] h-9 w-9 rounded-full border border-brisa transition-[width,height] mix-blend-difference" />
      <div ref={dot} className="pointer-events-none fixed left-0 top-0 z-[201] h-2 w-2 rounded-full bg-brisa" />
    </>
  );
}
