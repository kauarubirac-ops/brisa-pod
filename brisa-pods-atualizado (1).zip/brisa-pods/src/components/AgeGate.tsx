import { useState } from 'react';
import { useStore } from '../store';

export default function AgeGate() {
  const { state } = useStore();
  const [ok, setOk] = useState(() => localStorage.getItem('brisa-age') === 'ok');
  if (!state.settings.ageGate || ok) return null;
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/95 p-6 backdrop-blur-md">
      <div className="max-w-md text-center">
        {state.settings.logo && <img src={state.settings.logo} alt="" className="mx-auto mb-6 h-20 w-auto" />}
        <h2 className="font-display text-5xl uppercase text-white">Você tem 18 anos ou mais?</h2>
        <p className="mt-4 text-sm text-white/60">Este site é destinado exclusivamente a maiores de idade.</p>
        <div className="mt-8 flex justify-center gap-3">
          <button onClick={() => { localStorage.setItem('brisa-age', 'ok'); setOk(true); }} className="rounded-full bg-brisa px-8 py-3 text-sm font-bold uppercase tracking-widest text-white hover:brightness-110">Sim, tenho</button>
          <a href="https://www.google.com" className="rounded-full border border-white/30 px-8 py-3 text-sm font-bold uppercase tracking-widest text-white hover:bg-white/10">Sair</a>
        </div>
      </div>
    </div>
  );
}
