import { useEffect, useRef } from 'react';

interface Props {
  color: string; // "r g b"
  intensity: number; // 0-100
  alpha?: number;
  bottom?: boolean; // fumaça nasce embaixo (camada da frente)
  style?: React.CSSProperties;
}

interface Puff { x: number; y: number; r: number; vx: number; vy: number; life: number; max: number; rot: number }

/** Fumaça vermelha feita em canvas: puffs suaves que sobem e fogem do mouse. */
export default function SmokeCanvas({ color, intensity, alpha = 0.5, bottom = false, style }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const [r, g, b] = color.split(' ').map(Number);
    const sprite = document.createElement('canvas');
    sprite.width = sprite.height = 128;
    const sctx = sprite.getContext('2d')!;
    const grd = sctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    grd.addColorStop(0, `rgba(${r},${g},${b},0.9)`);
    grd.addColorStop(0.4, `rgba(${r},${g},${b},0.35)`);
    grd.addColorStop(1, `rgba(${r},${g},${b},0)`);
    sctx.fillStyle = grd;
    sctx.fillRect(0, 0, 128, 128);

    let w = 0, h = 0, raf = 0, visible = true;
    const mouse = { x: -9999, y: -9999 };
    const count = Math.max(4, Math.round((6 + intensity * 0.32) * (bottom ? 0.7 : 1)));
    const puffs: Puff[] = [];

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      w = rect.width; h = rect.height;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const spawn = (initial: boolean): Puff => {
      const rr = (bottom ? 120 : 90) + Math.random() * 200;
      return {
        x: Math.random() * w,
        y: initial ? Math.random() * h : h + rr * 0.4,
        r: rr,
        vx: (Math.random() - 0.5) * 0.35,
        vy: -(0.15 + Math.random() * 0.5),
        life: initial ? Math.random() * 300 : 0,
        max: 420 + Math.random() * 420,
        rot: Math.random() * 6.28,
      };
    };
    resize();
    for (let i = 0; i < count; i++) puffs.push(spawn(true));

    const onMove = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };
    const tick = () => {
      raf = requestAnimationFrame(tick);
      if (!visible || document.hidden) return;
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < puffs.length; i++) {
        const p = puffs[i];
        p.life++;
        if (p.life > p.max || p.y < -p.r) { puffs[i] = spawn(false); continue; }
        const dx = p.x - mouse.x, dy = p.y - mouse.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < 160 * 160) {
          const d = Math.sqrt(d2) || 1;
          p.vx += (dx / d) * 0.05;
          p.vy += (dy / d) * 0.05;
        }
        p.vx *= 0.99; p.vy = p.vy * 0.99 - 0.002;
        p.x += p.vx + Math.sin((p.life + p.rot * 40) / 90) * 0.25;
        p.y += p.vy;
        const t = p.life / p.max;
        const a = Math.sin(Math.PI * t) * alpha * (0.35 + intensity / 100);
        const size = p.r * (1 + t * 0.9);
        ctx.globalAlpha = Math.max(0, Math.min(1, a));
        ctx.drawImage(sprite, p.x - size, p.y - size, size * 2, size * 2);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
    };
    const io = new IntersectionObserver(([en]) => { visible = en.isIntersecting; });
    io.observe(canvas);
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', onMove);
    tick();
    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
    };
  }, [color, intensity, alpha, bottom]);

  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" style={style} aria-hidden="true" />;
}
