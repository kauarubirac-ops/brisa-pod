import { useEffect, useRef, useState, type ReactNode, type CSSProperties } from 'react';

export function useInView<T extends Element>(once = true, threshold = 0.2) {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([en]) => {
      if (en.isIntersecting) { setSeen(true); if (once) io.disconnect(); }
      else if (!once) setSeen(false);
    }, { threshold });
    io.observe(el);
    return () => io.disconnect();
  }, [once, threshold]);
  return [ref, seen] as const;
}

/** Fade + subida quando entra na tela. */
export function Reveal({ children, enabled, delay = 0, className = '' }: { children: ReactNode; enabled: boolean; delay?: number; className?: string }) {
  const [ref, seen] = useInView<HTMLDivElement>();
  if (!enabled) return <div className={className}>{children}</div>;
  const style: CSSProperties = {
    opacity: seen ? 1 : 0,
    transform: seen ? 'none' : 'translateY(28px)',
    transition: `opacity .7s cubic-bezier(.2,.8,.2,1) ${delay}ms, transform .7s cubic-bezier(.2,.8,.2,1) ${delay}ms`,
  };
  return <div ref={ref} className={className} style={style}>{children}</div>;
}

/** Letras embaralham (estilo painel de aeroporto) e travam da esquerda para a direita. */
export function ScrambleText({ text, enabled, className = '' }: { text: string; enabled: boolean; className?: string }) {
  const [ref, seen] = useInView<HTMLSpanElement>();
  const [out, setOut] = useState(text);
  useEffect(() => {
    if (!enabled) { setOut(text); return; }
    if (!seen) { setOut(text.replace(/[^\s]/g, '·')); return; }
    const chars = '█▓▒░/\\#@!%&*+=';
    let frame = 0;
    const id = window.setInterval(() => {
      frame++;
      const locked = Math.floor(frame / 3);
      setOut(text.split('').map((c, i) => (c === ' ' ? ' ' : i < locked ? c : chars[Math.floor(Math.random() * chars.length)])).join(''));
      if (locked >= text.length) { window.clearInterval(id); setOut(text); }
    }, 35);
    return () => window.clearInterval(id);
  }, [text, enabled, seen]);
  return <span ref={ref} className={className} aria-label={text}>{out}</span>;
}

/** Palavras entram uma a uma com atraso. */
export function WordReveal({ text, enabled, className = '' }: { text: string; enabled: boolean; className?: string }) {
  const [ref, seen] = useInView<HTMLParagraphElement>();
  if (!enabled) return <p className={className}>{text}</p>;
  return (
    <p ref={ref} className={className}>
      {text.split(' ').map((w, i) => (
        <span key={i} className="inline-block overflow-hidden align-bottom">
          <span
            className="inline-block"
            style={{
              transform: seen ? 'none' : 'translateY(110%)',
              transition: `transform .6s cubic-bezier(.2,.8,.2,1) ${i * 70}ms`,
            }}
          >
            {w}&nbsp;
          </span>
        </span>
      ))}
    </p>
  );
}

/** Botão elástico: mola real (rigidez + amortecimento) que puxa em direção ao mouse. */
export function MagneticLink({ href, children, enabled, className = '', onClick, target, rel }: {
  href: string; children: ReactNode; enabled: boolean; className?: string; onClick?: () => void; target?: string; rel?: string;
}) {
  const ref = useRef<HTMLAnchorElement>(null);
  const st = useRef({ x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: 0, raf: 0 });

  useEffect(() => {
    if (!enabled) return;
    const el = ref.current;
    if (!el) return;
    const s = st.current;
    const loop = () => {
      const k = 0.14, damping = 0.78;
      s.vx = (s.vx + (s.tx - s.x) * k) * damping;
      s.vy = (s.vy + (s.ty - s.y) * k) * damping;
      s.x += s.vx; s.y += s.vy;
      el.style.transform = `translate(${s.x}px, ${s.y}px)`;
      if (Math.abs(s.vx) + Math.abs(s.vy) + Math.abs(s.tx - s.x) + Math.abs(s.ty - s.y) > 0.05) s.raf = requestAnimationFrame(loop);
      else s.raf = 0;
    };
    const kick = () => { if (!s.raf) s.raf = requestAnimationFrame(loop); };
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      s.tx = (e.clientX - (r.left + r.width / 2)) * 0.3;
      s.ty = (e.clientY - (r.top + r.height / 2)) * 0.3;
      kick();
    };
    const leave = () => { s.tx = 0; s.ty = 0; kick(); };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerleave', leave);
    return () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerleave', leave);
      cancelAnimationFrame(s.raf);
    };
  }, [enabled]);

  return <a ref={ref} href={href} onClick={onClick} target={target} rel={rel} className={className}>{children}</a>;
}
