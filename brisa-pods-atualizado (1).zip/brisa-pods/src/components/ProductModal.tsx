import { useEffect, useState } from 'react';
import { Box, ImageIcon, MessageCircle, X } from 'lucide-react';
import { useStore } from '../store';
import type { Product } from '../types';
import { money, whatsappLink } from '../lib/util';
import ModelViewer from './ModelViewer';

export default function ProductModal({ product, onClose }: { product: Product; onClose: () => void }) {
  const { state } = useStore();
  const s = state.settings;
  const [view3d, setView3d] = useState(false);
  const model = product.model || (s.useModelInHero ? s.heroModel : '');
  const out = product.stock <= 0;
  const link = whatsappLink(s, product.name);

  useEffect(() => {
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', on);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', on); document.body.style.overflow = ''; };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="relative grid max-h-[92vh] w-full max-w-4xl animate-fadeUp overflow-auto rounded-3xl border border-brisa/40 bg-ink md:grid-cols-2" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} aria-label="Fechar" className="absolute right-4 top-4 z-10 rounded-full border border-white/30 p-2 text-white hover:bg-white/10"><X size={18} /></button>
        <div className="relative flex min-h-[320px] items-end justify-center" style={{ background: `radial-gradient(circle at 50% 80%, ${product.bg}, #050505 80%)` }}>
          {view3d && model ? (
            <div className="absolute inset-0"><ModelViewer src={model} /></div>
          ) : (
            <img src={product.image} alt={product.name} className="h-[360px] w-auto max-w-full object-contain md:h-[460px]" draggable={false} />
          )}
          {model && (
            <button onClick={() => setView3d((v) => !v)} className="absolute bottom-4 left-4 flex items-center gap-2 rounded-full bg-black/70 px-4 py-2 text-xs font-bold uppercase tracking-widest text-white hover:bg-brisa">
              {view3d ? <><ImageIcon size={14} /> Foto</> : <><Box size={14} /> Ver em 3D</>}
            </button>
          )}
        </div>
        <div className="flex flex-col p-6 sm:p-8">
          <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-brisa">{product.category}</p>
          <h3 className="mt-2 font-display text-5xl uppercase leading-none text-white">{product.name}</h3>
          <p className="mt-2 text-sm text-white/60">{product.flavor}{product.puffs ? ` · ${product.puffs}` : ''}</p>
          <p className="mt-5 text-sm leading-relaxed text-white/80">{product.description}</p>
          <p className="mt-6 text-3xl font-bold text-white">{money(product.price, s.currency)}</p>
          <p className={`mt-2 text-xs font-bold uppercase tracking-widest ${out ? 'text-white/50' : 'text-brisa'}`}>
            {out ? 'Esgotado' : s.showStock ? `${product.stock} unidades em estoque` : 'Disponível'}
          </p>
          <div className="mt-auto pt-6">
            {link && !out ? (
              <a href={link} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-full bg-brisa px-6 py-4 text-sm font-bold uppercase tracking-widest text-white transition hover:brightness-110">
                <MessageCircle size={18} /> Pedir no WhatsApp
              </a>
            ) : out ? (
              <a href={`/conta?reserve=${encodeURIComponent(product.id)}`} className="flex w-full items-center justify-center rounded-full bg-brisa px-6 py-4 text-sm font-bold uppercase tracking-widest text-white transition hover:brightness-110">Reservar quando voltar ao estoque</a>
            ) : (
              <button disabled className="w-full cursor-not-allowed rounded-full border border-white/20 px-6 py-4 text-sm font-bold uppercase tracking-widest text-white/40">Contato em breve</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
