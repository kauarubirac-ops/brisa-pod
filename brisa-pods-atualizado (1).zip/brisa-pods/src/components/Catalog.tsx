import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { useStore } from '../store';
import type { Product } from '../types';
import { money } from '../lib/util';
import { Reveal, ScrambleText, WordReveal } from './Effects';

function ProductCard({ p, onOpen }: { p: Product; onOpen: (p: Product) => void }) {
  const { state } = useStore();
  const s = state.settings;
  const a = s.anim;
  const out = p.stock <= 0;

  const onMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    el.style.setProperty('--mx', `${x}px`);
    el.style.setProperty('--my', `${y}px`);
    if (a.tilt) {
      const rx = (0.5 - y / r.height) * 10, ry = (x / r.width - 0.5) * 12;
      el.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateZ(0)`;
    }
  };
  const onLeave = (e: React.PointerEvent<HTMLButtonElement>) => { e.currentTarget.style.transform = ''; };

  return (
    <button
      type="button"
      onClick={() => onOpen(p)}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className={`pcard ${a.spotlight ? 'spot' : ''} group w-full overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] text-left hover:border-brisa/60`}
      data-hover
    >
      <div className="relative flex aspect-[4/5] items-end justify-center overflow-hidden" style={{ background: `radial-gradient(circle at 50% 80%, ${p.bg}, transparent 75%), linear-gradient(#111,#050505)` }}>
        <img src={p.image} alt={p.name} draggable={false} className={`h-[88%] w-auto object-contain transition-transform duration-500 group-hover:scale-110 ${out ? 'grayscale opacity-60' : ''}`} />
        {p.model && <span className="absolute left-3 top-3 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-bold tracking-widest text-white">3D</span>}
        <span className={`absolute right-3 top-3 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-widest ${out ? 'bg-white text-black' : 'bg-brisa text-white'}`}>
          {out ? 'Esgotado' : s.showStock ? `${p.stock} em estoque` : 'Disponível'}
        </span>
      </div>
      <div className="p-4">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-brisa">{p.category}</p>
        <h3 className="mt-1 font-display text-2xl uppercase tracking-wide text-white">{p.name}</h3>
        <p className="mt-1 text-xs text-white/60">{p.flavor}{p.puffs ? ` · ${p.puffs}` : ''}</p>
        <p className="mt-3 text-lg font-bold text-white">{money(p.price, s.currency)}</p>
      </div>
    </button>
  );
}

export default function Catalog({ onOpen }: { onOpen: (p: Product) => void }) {
  const { state } = useStore();
  const s = state.settings;
  const a = s.anim;
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');

  const published = state.products.filter((p) => p.published);
  const cats = useMemo(() => Array.from(new Set(published.map((p) => p.category).filter(Boolean))), [published]);
  const list = published.filter(
    (p) => (cat === 'all' || p.category === cat) && `${p.name} ${p.flavor} ${p.category}`.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <section id="catalogo" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-8 sm:py-28">
      <div className="mb-10 flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <div>
          <p className="mb-3 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-brisa"><i className="inline-block h-px w-10 bg-brisa" /> Seleção</p>
          <h2 className="font-display text-6xl uppercase leading-none text-white sm:text-8xl">
            <ScrambleText text={s.catalogTitle} enabled={a.scramble} />
          </h2>
          <WordReveal text={s.catalogSubtitle} enabled={a.wordReveal} className="mt-4 max-w-xl text-sm text-white/70" />
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <label className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2.5">
            <Search size={16} className="text-brisa" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar..." className="w-44 bg-transparent text-sm text-white outline-none placeholder:text-white/40" />
          </label>
          <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-full border border-white/15 bg-black px-4 py-2.5 text-sm text-white outline-none">
            <option value="all">Todas as categorias</option>
            {cats.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      {list.length === 0 ? (
        <p className="py-20 text-center text-white/50">Nenhum produto encontrado.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
          {list.map((p, i) => (
            <Reveal key={p.id} enabled={a.scrollReveal} delay={(i % 4) * 90}>
              <ProductCard p={p} onOpen={onOpen} />
            </Reveal>
          ))}
        </div>
      )}
    </section>
  );
}
