import { useEffect, useRef } from 'react';

/** Rastro vermelho que segue o mouse e se dissolve (tela escurecida aos poucos). */
export default function FluidTrail({ color }: { color: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    if (!window.matchMedia('(pointer: fine)').matches) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const [r, g, b] = color.split(' ').map(Number);
    let raf = 0, idle = 0, running = false;
    let last: { x: number; y: number } | null = null;

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();

    const frame = () => {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0,0,0,0.06)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.globalCompositeOperation = 'source-over';
      idle++;
      if (idle > 140) { running = false; ctx.clearRect(0, 0, canvas.width, canvas.height); return; }
      raf = requestAnimationFrame(frame);
    };
    const onMove = (e: PointerEvent) => {
      const p = { x: e.clientX, y: e.clientY };
      if (last) {
        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 38);
        grad.addColorStop(0, `rgba(${r},${g},${b},0.55)`);
        grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
        ctx.strokeStyle = `rgba(${r},${g},${b},0.35)`;
        ctx.lineWidth = 14;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.arc(p.x, p.y, 38, 0, Math.PI * 2); ctx.fill();
      }
      last = p; idle = 0;
      if (!running) { running = true; raf = requestAnimationFrame(frame); }
    };
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', onMove);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
    };
  }, [color]);

  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-[45] mix-blend-screen" aria-hidden="true" />;
}
