import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useStore } from '../store';
import type { Product } from '../types';
import { EASINGS, hexToRgbTriplet } from '../lib/util';
import SmokeCanvas from './SmokeCanvas';
import ModelViewer from './ModelViewer';
import { MagneticLink } from './Effects';

type Role = 'center' | 'left' | 'right' | 'back' | 'hidden';

function roleOf(i: number, active: number, n: number): Role {
  const d = (i - active + n) % n;
  if (d === 0) return 'center';
  if (n === 1) return 'hidden';
  if (d === 1) return 'right';
  if (d === n - 1) return 'left';
  return d === Math.floor(n / 2) ? 'back' : 'hidden';
}

export default function Hero({ onOpen }: { onOpen: (p: Product) => void }) {
  const { state } = useStore();
  const s = state.settings;
  const a = s.anim;
  const items = state.products.filter((p) => p.published && p.featured);
  const n = items.length;

  const [active, setActive] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 640);
  const lock = useRef(false);
  const hover = useRef(false);
  const touchX = useRef<number | null>(null);
  const mx = useRef(0);
  const [ghostShift, setGhostShift] = useState(0);

  const idx = n ? active % n : 0;
  const center = items[idx];
  const ease = EASINGS[a.easing] ?? EASINGS.suave;
  const dur = a.carouselMs;

  useEffect(() => {
    const on = () => setIsMobile(window.innerWidth < 640);
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);

  // pré-carrega as imagens
  useEffect(() => {
    items.forEach((p) => { const im = new Image(); im.src = p.image; });
  }, [items.map((p) => p.image).join('|')]); // eslint-disable-line react-hooks/exhaustive-deps

  const navigate = useCallback((dir: 'next' | 'prev') => {
    if (lock.current || n < 2) return;
    lock.current = true;
    setActive((prev) => (dir === 'next' ? (prev + 1) % n : (prev + n - 1) % n));
    window.setTimeout(() => { lock.current = false; }, dur);
  }, [n, dur]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') navigate('next');
      if (e.key === 'ArrowLeft') navigate('prev');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [navigate]);

  useEffect(() => {
    if (!a.autoplay || n < 2) return;
    const id = window.setInterval(() => { if (!hover.current) navigate('next'); }, Math.max(1500, a.autoplayMs));
    return () => window.clearInterval(id);
  }, [a.autoplay, a.autoplayMs, n, navigate]);

  // parallax do texto fantasma
  useEffect(() => {
    if (!a.ghostParallax) { setGhostShift(0); return; }
    let raf = 0;
    const on = (e: PointerEvent) => {
      mx.current = (e.clientX / window.innerWidth - 0.5) * -40;
      if (!raf) raf = requestAnimationFrame(() => { setGhostShift(mx.current); raf = 0; });
    };
    window.addEventListener('pointermove', on);
    return () => { window.removeEventListener('pointermove', on); cancelAnimationFrame(raf); };
  }, [a.ghostParallax]);

  const bg = center?.bg ?? s.colors.black;
  const red = hexToRgbTriplet(s.colors.red);
  const modelSrc = s.useModelInHero ? center?.model || s.heroModel : '';
  const tr = `transform ${dur}ms ${ease}, filter ${dur}ms ${ease}, opacity ${dur}ms ${ease}, left ${dur}ms ${ease}, height ${dur}ms ${ease}, bottom ${dur}ms ${ease}`;

  const itemStyle = (role: Role): React.CSSProperties => {
    const base: React.CSSProperties = { position: 'absolute', aspectRatio: '0.6 / 1', transition: tr, willChange: 'transform, filter, opacity' };
    switch (role) {
      case 'center':
        return { ...base, transform: `translateX(-50%) scale(${isMobile ? 1.25 : 1.68})`, filter: 'blur(0px)', opacity: 1, zIndex: 20, left: '50%', height: isMobile ? '60%' : '92%', bottom: isMobile ? '22%' : 0 };
      case 'left':
        return { ...base, transform: 'translateX(-50%) scale(1)', filter: 'blur(2px)', opacity: 0.85, zIndex: 10, left: isMobile ? '20%' : '30%', height: isMobile ? '16%' : '28%', bottom: isMobile ? '32%' : '12%' };
      case 'right':
        return { ...base, transform: 'translateX(-50%) scale(1)', filter: 'blur(2px)', opacity: 0.85, zIndex: 10, left: isMobile ? '80%' : '70%', height: isMobile ? '16%' : '28%', bottom: isMobile ? '32%' : '12%' };
      case 'back':
        return { ...base, transform: 'translateX(-50%) scale(1)', filter: 'blur(4px)', opacity: 1, zIndex: 5, left: '50%', height: isMobile ? '13%' : '22%', bottom: isMobile ? '32%' : '12%' };
      default:
        return { ...base, transform: 'translateX(-50%) scale(1)', filter: 'blur(4px)', opacity: 0, zIndex: 1, left: '50%', height: isMobile ? '13%' : '22%', bottom: isMobile ? '32%' : '12%', pointerEvents: 'none' };
    }
  };

  const onItemClick = (role: Role, p: Product) => {
    if (role === 'center') onOpen(p);
    else if (role === 'left') navigate('prev');
    else if (role === 'right') navigate('next');
  };

  return (
    <div
      id="inicio"
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: bg, transition: `background-color ${dur}ms ${ease}`, fontFamily: 'Inter, sans-serif' }}
      onPointerEnter={() => { hover.current = true; }}
      onPointerLeave={() => { hover.current = false; }}
      onPointerDown={(e) => { if (e.pointerType === 'touch') touchX.current = e.clientX; }}
      onPointerUp={(e) => {
        if (touchX.current === null) return;
        const dx = e.clientX - touchX.current;
        touchX.current = null;
        if (Math.abs(dx) > 50) navigate(dx < 0 ? 'next' : 'prev');
      }}
    >
      <div className="relative w-full" style={{ height: '100vh', overflow: 'hidden' }}>
        {/* vinheta + brilho central */}
        <div className="pointer-events-none absolute inset-0" style={{ zIndex: 1, background: `radial-gradient(ellipse at 50% 70%, rgba(255,255,255,0.10), transparent 55%), radial-gradient(ellipse at 50% 120%, rgba(0,0,0,0.55), transparent 60%)` }} />

        {/* fumaça de trás */}
        {a.smokeCanvas && <div className="absolute inset-0" style={{ zIndex: 1 }}><SmokeCanvas color={red} intensity={a.smokeIntensity} alpha={0.5} /></div>}

        {/* 1. Grain */}
        {a.grain && (
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              zIndex: 50,
              opacity: a.grainOpacity / 100,
              backgroundSize: '200px 200px',
              backgroundRepeat: 'repeat',
              backgroundImage: `url("data:image/svg+xml;utf8,${encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(#n)' opacity='0.08'/></svg>")}")`,
            }}
          />
        )}

        {/* 2. Texto fantasma */}
        <div className="pointer-events-none absolute inset-x-0 flex select-none items-center justify-center" style={{ zIndex: 2, top: '18%' }}>
          <span
            className="font-display"
            style={{
              fontFamily: 'Anton, sans-serif', fontSize: 'clamp(90px, 28vw, 380px)', fontWeight: 900, color: 'var(--ghost)', opacity: 1,
              lineHeight: 1, textTransform: 'uppercase', letterSpacing: '-0.02em', whiteSpace: 'nowrap',
              transform: `translateX(${ghostShift}px)`, transition: 'transform 0.4s cubic-bezier(.2,.8,.2,1)',
            }}
          >
            {s.ghostText}
          </span>
        </div>

        {/* 3. Logo / marca */}
        <a href="#inicio" className="absolute left-4 top-6 sm:left-8" style={{ zIndex: 60 }} aria-label={s.brandName}>
          {s.logo ? (
            <img src={s.logo} alt={s.brandName} style={{ height: s.logoHeight, width: 'auto', filter: 'drop-shadow(0 2px 12px rgba(0,0,0,.55))' }} draggable={false} />
          ) : (
            <span className="text-xs font-semibold uppercase text-white" style={{ opacity: 0.9, letterSpacing: '0.18em' }}>{s.brandName}</span>
          )}
        </a>
        <nav className="absolute right-4 top-8 hidden gap-8 text-[11px] font-bold uppercase tracking-[0.2em] text-white sm:flex sm:right-10" style={{ zIndex: 60 }}>
          <a href="#catalogo" className="glitch-hover opacity-90 hover:opacity-100">Catálogo</a>
          <a href="#marca" className="glitch-hover opacity-90 hover:opacity-100">Marca</a>
        </nav>

        {/* 4. Carrossel */}
        <div className="pointer-events-none absolute inset-0" style={{ zIndex: 3 }}>
          {items.map((p, i) => {
            const role = roleOf(i, idx, n);
            const showModel = role === 'center' && !!modelSrc;
            return (
              <div
                key={p.id}
                style={{ ...itemStyle(role), pointerEvents: role === 'hidden' ? 'none' : 'auto', cursor: 'pointer' }}
                onClick={() => onItemClick(role, p)}
                data-hover
              >
                <div className={role === 'center' && a.float ? 'h-full w-full animate-float' : 'h-full w-full'}>
                  {showModel ? (
                    <ModelViewer src={modelSrc} />
                  ) : (
                    <img src={p.image} alt={p.name} draggable={false} style={{ width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'bottom center' }} />
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* fumaça da frente (a figura emerge da fumaça) */}
        {a.smokeCanvas && a.smokeFront && (
          <div className="pointer-events-none absolute inset-x-0 bottom-0" style={{ zIndex: 30, height: '45%' }}>
            <SmokeCanvas color={red} intensity={a.smokeIntensity * 0.8} alpha={0.32} bottom />
          </div>
        )}

        {/* 5. Texto + botões */}
        <div className="absolute bottom-6 left-4 sm:bottom-20 sm:left-24" style={{ zIndex: 60, maxWidth: 320 }}>
          <div key={center?.id ?? 'x'} className="animate-fadeUp">
            <p className="mb-2 text-base font-bold uppercase text-white sm:mb-3 sm:text-[22px]" style={{ letterSpacing: '0.02em', opacity: 0.95 }}>
              {center ? center.name : s.heroLabel}
            </p>
            <p className="mb-4 hidden text-xs text-white sm:mb-5 sm:block sm:text-sm" style={{ opacity: 0.85, lineHeight: 1.6 }}>
              {center ? `${center.flavor}${center.puffs ? ' · ' + center.puffs : ''}. ${center.description}` : s.heroText}
            </p>
          </div>
          {n > 1 && (
            <div className="flex gap-3">
              {(['prev', 'next'] as const).map((dir) => (
                <button
                  key={dir}
                  type="button"
                  aria-label={dir === 'prev' ? 'Anterior' : 'Próximo'}
                  onClick={() => navigate(dir)}
                  className="flex h-12 w-12 items-center justify-center rounded-full text-white sm:h-16 sm:w-16"
                  style={{ background: 'transparent', border: '2px solid #fff', transition: 'transform 150ms, background-color 150ms' }}
                  onMouseEnter={(e) => { e.currentTarget.style.transform = 'scale(1.08)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.12)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  {dir === 'prev' ? <ArrowLeft size={26} strokeWidth={2.25} /> : <ArrowRight size={26} strokeWidth={2.25} />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 6. DISCOVER IT */}
        <div className="absolute bottom-6 right-4 sm:bottom-20 sm:right-10" style={{ zIndex: 60 }}>
          <MagneticLink
            href="#catalogo"
            enabled={a.magnetic}
            className="flex items-center text-white uppercase"
          >
            <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 'clamp(20px, 4vw, 56px)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1, opacity: 0.95 }}>{s.ctaLabel}</span>
            <ArrowRight className="ml-2 h-5 w-5 sm:h-8 sm:w-8" strokeWidth={2.25} />
          </MagneticLink>
        </div>
      </div>
    </div>
  );
}
