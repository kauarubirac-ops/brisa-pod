import { createElement, useEffect, useState } from 'react';

/** Visualizador 3D (.glb) — carrega @google/model-viewer só quando necessário. */
export default function ModelViewer({ src, autoRotate = true, controls = true, className = '' }: { src: string; autoRotate?: boolean; controls?: boolean; className?: string }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    import('@google/model-viewer').then(() => alive && setReady(true)).catch(() => alive && setReady(false));
    return () => { alive = false; };
  }, []);
  if (!ready) return <div className={`grid h-full w-full place-items-center text-xs tracking-widest text-white/60 ${className}`}>CARREGANDO 3D…</div>;
  const props: Record<string, unknown> = {
    src,
    'shadow-intensity': '1',
    'interaction-prompt': 'none',
    'camera-orbit': 'auto auto auto',
    style: { width: '100%', height: '100%', background: 'transparent', '--poster-color': 'transparent' },
  };
  if (autoRotate) props['auto-rotate'] = '';
  if (controls) props['camera-controls'] = '';
  return createElement('model-viewer', props as never);
}
