import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { SiteState } from './types';
import { DEFAULT_STATE } from './defaults';
import { idbDel, idbGet, idbSet } from './lib/idb';
import { hexToRgbTriplet } from './lib/util';
import { supabase, supabaseConfigured } from './lib/supabase';

const KEY = 'state';
const CHANNEL = 'brisa-sync';

interface Ctx {
  state: SiteState;
  loaded: boolean;
  source: 'local' | 'catalog.json' | 'default';
  update: (fn: (s: SiteState) => SiteState) => void;
  replace: (s: SiteState) => void;
  resetToPublished: () => Promise<void>;
}

const StoreCtx = createContext<Ctx | null>(null);

/** Completa campos que faltam (ex.: arquivo antigo) com os valores padrão. */
function normalize(raw: Partial<SiteState> | undefined): SiteState {
  const d = DEFAULT_STATE;
  if (!raw) return d;
  return {
    version: raw.version ?? d.version,
    updatedAt: raw.updatedAt ?? 0,
    products: Array.isArray(raw.products) ? raw.products : d.products,
    settings: {
      ...d.settings,
      ...(raw.settings ?? {}),
      colors: { ...d.settings.colors, ...(raw.settings?.colors ?? {}) },
      anim: { ...d.settings.anim, ...(raw.settings?.anim ?? {}) },
    },
  };
}

async function fetchRemote(): Promise<SiteState | null> {
  if (!supabase) return null;
  try { const { data, error } = await supabase.from('site_state').select('state').eq('id', 1).maybeSingle(); if (error || !data?.state) return null; const parsed = normalize(data.state as Partial<SiteState>); parsed.settings.adminPasswordHash = ''; return parsed; } catch { return null; }
}

async function fetchPublished(): Promise<SiteState | null> {
  try {
    const r = await fetch('/catalog.json', { cache: 'no-store' });
    if (!r.ok) return null;
    const type = r.headers.get('content-type') ?? '';
    if (!type.includes('json')) return null; // SPA fallback devolveria HTML
    return normalize((await r.json()) as Partial<SiteState>);
  } catch {
    return null;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SiteState>(DEFAULT_STATE);
  const [loaded, setLoaded] = useState(false);
  const [source, setSource] = useState<Ctx['source']>('default');
  const skipSave = useRef(true);
  const timer = useRef<number | undefined>(undefined);
  const channel = useRef<BroadcastChannel | null>(null);

  const load = useCallback(async () => {
    const remote = await fetchRemote();
    if (remote) { setState(remote); setSource('catalog.json'); }
    else {
      const local = await idbGet<Partial<SiteState>>(KEY);
      if (local) { setState(normalize(local)); setSource('local'); }
      else { const pub = await fetchPublished(); setState(pub ?? DEFAULT_STATE); setSource(pub ? 'catalog.json' : 'default'); }
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    void load();
    if ('BroadcastChannel' in window) {
      channel.current = new BroadcastChannel(CHANNEL);
      channel.current.onmessage = () => {
        skipSave.current = true;
        void load();
      };
    }
    return () => channel.current?.close();
  }, [load]);

  // salva (com debounce) sempre que o estado muda por ação do admin
  useEffect(() => {
    if (!loaded) return;
    if (skipSave.current) {
      skipSave.current = false;
      return;
    }
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(async () => {
      try {
        await idbSet(KEY, state);
        if (supabase) {
          const { data: sessionData } = await supabase.auth.getSession();
          if (sessionData.session) {
            const { data: profile } = await supabase.from('profiles').select('role').eq('id', sessionData.session.user.id).maybeSingle();
            if (profile?.role === 'admin') {
              const safeState = { ...state, settings: { ...state.settings, adminPasswordHash: '' } };
              const { error } = await supabase.from('site_state').upsert({ id: 1, state: safeState, updated_at: new Date().toISOString(), updated_by: sessionData.session.user.id });
              if (error) throw error;
              setSource('catalog.json');
            } else setSource('local');
          } else setSource('local');
        } else setSource('local');
        channel.current?.postMessage('changed');
      } catch (e) {
        console.error('Falha ao salvar', e);
        alert('Não foi possível salvar (armazenamento cheio?). Use imagens menores ou exporte o catálogo.');
      }
    }, 350);
  }, [state, loaded]);

  // aplica tema (cores) em variáveis CSS
  useEffect(() => {
    const root = document.documentElement.style;
    const c = state.settings.colors;
    root.setProperty('--red-rgb', hexToRgbTriplet(c.red));
    root.setProperty('--black-rgb', hexToRgbTriplet(c.black));
    root.setProperty('--ghost', c.ghost);
    document.title = state.settings.brandName;
  }, [state.settings.colors, state.settings.brandName]);

  const update = useCallback((fn: (s: SiteState) => SiteState) => {
    setState((prev) => ({ ...fn(prev), updatedAt: Date.now() }));
  }, []);

  const replace = useCallback((s: SiteState) => setState({ ...normalize(s), updatedAt: Date.now() }), []);

  const resetToPublished = useCallback(async () => {
    await idbDel(KEY);
    skipSave.current = true;
    await load();
    channel.current?.postMessage('changed');
  }, [load]);

  const value = useMemo(
    () => ({ state, loaded, source, update, replace, resetToPublished }),
    [state, loaded, source, update, replace, resetToPublished],
  );
  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore(): Ctx {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error('useStore fora do StoreProvider');
  return ctx;
}
