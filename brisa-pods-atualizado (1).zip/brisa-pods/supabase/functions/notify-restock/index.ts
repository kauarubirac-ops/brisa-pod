import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const url = Deno.env.get('SUPABASE_URL')!; const anon = Deno.env.get('SUPABASE_ANON_KEY')!; const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const auth = req.headers.get('Authorization'); if (!auth) return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers:{...cors,'Content-Type':'application/json'}});
    const userClient = createClient(url, anon, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userClient.auth.getUser(); if (!user) return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers:{...cors,'Content-Type':'application/json'}});
    const { data: profile } = await userClient.from('profiles').select('role').eq('id', user.id).maybeSingle(); if (profile?.role !== 'admin') return new Response(JSON.stringify({error:'Forbidden'}),{status:403,headers:{...cors,'Content-Type':'application/json'}});
    const { reservation_id } = await req.json(); const admin = createClient(url, service);
    const { data: r, error } = await admin.from('reservations').select('*').eq('id', reservation_id).single(); if (error || !r) throw new Error('Reserva não encontrada');
    const [{ data: p }, { data: u }] = await Promise.all([admin.from('profiles').select('*').eq('id',r.customer_id).single(), admin.auth.admin.getUserById(r.customer_id)]);
    const email = u.user?.email; const results: string[] = [];
    const resendKey = Deno.env.get('RESEND_API_KEY'); const from = Deno.env.get('RESEND_FROM_EMAIL');
    if (resendKey && from && email) {
      const response = await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${resendKey}`,'Content-Type':'application/json'},body:JSON.stringify({from,to:[email],subject:`${r.product_name} voltou ao estoque`,html:`<p>Olá, ${p?.full_name||'cliente'}!</p><p>O produto <strong>${r.product_name}</strong> da sua reserva está disponível novamente. Entre em contato com a Brisa Pods para concluir o pedido.</p>`})});
      if (!response.ok) throw new Error(`Falha no e-mail: ${await response.text()}`); results.push('email');
    }
    const sid=Deno.env.get('TWILIO_ACCOUNT_SID'), token=Deno.env.get('TWILIO_AUTH_TOKEN'), fromPhone=Deno.env.get('TWILIO_FROM_PHONE');
    if(sid&&token&&fromPhone&&p?.phone){const body=new URLSearchParams({To:p.phone,From:fromPhone,Body:`Brisa Pods: ${r.product_name} voltou ao estoque! Sua reserva está pronta para ser concluída.`});const response=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,{method:'POST',headers:{Authorization:`Basic ${btoa(`${sid}:${token}`)}`,'Content-Type':'application/x-www-form-urlencoded'},body});if(!response.ok)throw new Error(`Falha no SMS: ${await response.text()}`);results.push('sms');}
    if(!results.length) return new Response(JSON.stringify({error:'Configure RESEND_API_KEY/RESEND_FROM_EMAIL e/ou credenciais Twilio para enviar notificações.'}),{status:503,headers:{...cors,'Content-Type':'application/json'}});
    return new Response(JSON.stringify({sent:results}),{headers:{...cors,'Content-Type':'application/json'}});
  } catch(e) { return new Response(JSON.stringify({error:e instanceof Error?e.message:'Erro interno'}),{status:400,headers:{...cors,'Content-Type':'application/json'}}); }
});
