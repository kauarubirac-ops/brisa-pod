-- Brisa Pods: execute no SQL Editor do Supabase.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '', cpf text not null default '',
  phone text not null default '', address text not null default '',
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, cpf, phone, address, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'cpf',''), coalesce(new.raw_user_meta_data->>'phone',''), coalesce(new.raw_user_meta_data->>'address',''), 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create table if not exists public.site_state (
  id integer primary key default 1 check (id = 1),
  state jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(), customer_id uuid not null references auth.users(id),
  product_id text not null, product_name text not null, quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  status text not null default 'new' check (status in ('new','delivered','cancelled')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','unpaid')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(), customer_id uuid not null references auth.users(id),
  product_id text not null, product_name text not null, quantity integer not null check (quantity > 0),
  status text not null default 'waiting' check (status in ('waiting','notified','converted','cancelled')),
  notified_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.site_state enable row level security;
alter table public.orders enable row level security;
alter table public.reservations enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
drop policy if exists "profile insert self as customer" on public.profiles;
create policy "profile insert self as customer" on public.profiles for insert to authenticated with check (id = auth.uid() and role = 'customer');
drop policy if exists "profile update self or admin" on public.profiles;
create policy "profile update self or admin" on public.profiles for update to authenticated using (id = auth.uid() or public.is_admin()) with check ((id = auth.uid() and role = 'customer') or public.is_admin());
drop policy if exists "public read site state" on public.site_state;
create policy "public read site state" on public.site_state for select to anon, authenticated using (true);
drop policy if exists "admin write site state" on public.site_state;
create policy "admin write site state" on public.site_state for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "customer read own orders or admin" on public.orders;
create policy "customer read own orders or admin" on public.orders for select to authenticated using (customer_id = auth.uid() or public.is_admin());
drop policy if exists "customer create own orders" on public.orders;
create policy "customer create own orders" on public.orders for insert to authenticated with check (customer_id = auth.uid());
drop policy if exists "admin update orders" on public.orders;
create policy "admin update orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "customer read own reservations or admin" on public.reservations;
create policy "customer read own reservations or admin" on public.reservations for select to authenticated using (customer_id = auth.uid() or public.is_admin());
drop policy if exists "customer create own reservations" on public.reservations;
create policy "customer create own reservations" on public.reservations for insert to authenticated with check (customer_id = auth.uid());
drop policy if exists "admin update reservations" on public.reservations;
create policy "admin update reservations" on public.reservations for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Registre o primeiro admin manualmente: crie o usuário em Authentication > Users,
-- depois execute: update public.profiles set role='admin' where id='UUID_DO_USUARIO';
-- Crie o perfil do usuário com os dados do cadastro. Não exponha service_role no front-end.
